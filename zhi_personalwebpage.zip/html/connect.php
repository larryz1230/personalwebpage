<?php

$conn = mysqli_connect("us-cdbr-east-02.cleardb.com", "b742eb78be7257", "8931e461", "heroku_3f181f69b51f626");

?>