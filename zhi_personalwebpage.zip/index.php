
<?php
header("Location: /html/home.html");
die();
?>
